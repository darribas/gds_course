Updated January 16, 2019. 
Written by Milenko Fadic 

Please note that the Functional Urban Areas geometries have been simplified. In case the user needs a more detailed geometry (such as for creating raster statistics), please contact RegionStat@oecd.org.